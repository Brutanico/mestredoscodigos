package mestredoscodigos;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javafx.application.Application;
import javafx.stage.Stage;
import mestredoscodigos.controllers.AppController;
import mestredoscodigos.controllers.AuthController;

public class App extends Application {

	private static final Logger LOGGER = LoggerFactory.getLogger(App.class);

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		LOGGER.info("Starting application");

		@SuppressWarnings("resource")
		ApplicationContext context = new AnnotationConfigApplicationContext("mestredoscodigos");

		AppController screens = context.getBean(AppController.class);
		screens.setPrimaryStage(primaryStage);
		screens.showMainScreen();
		screens.open(AuthController.class, getClass().getResource("/login.fxml"));

	}

}
