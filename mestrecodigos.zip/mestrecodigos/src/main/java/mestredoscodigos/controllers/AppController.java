package mestredoscodigos.controllers;

import java.net.URL;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.controlsfx.control.NotificationPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

@Component
public class AppController {

    private Stage primaryStage;
    private StackPane root;
    private NotificationPane notificationPane;

    private static final String ERROR_CASTING_NODE = "Error casting node";
    private static final Logger LOGGER = LogManager.getLogger(AppController.class);

    @Autowired
    private ApplicationContext applicationContext;

    public void showMainScreen() {
        root = new StackPane();
        notificationPane = new NotificationPane();
        notificationPane.setContent(root);
        notificationPane.setShowFromTop(true);

        Scene scene = new Scene(notificationPane);
//        scene.getStylesheets().add("/styles/styles.css");

        primaryStage.setTitle("title");
        primaryStage.setScene(scene);

//        Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
//        primaryStage.setX(primScreenBounds.getMinX() + primScreenBounds.getWidth() - WIDTH);
//        primaryStage.setY(primScreenBounds.getMinY() + primScreenBounds.getHeight() - HEIGHT);
        primaryStage.setOnCloseRequest(ev -> close());

//        Platform.setImplicitExit(false);

        primaryStage.show();
    }

    public void open(final Class<?> control, URL location) {
        notificationPane.hide();
        Node node = getNode(control, location);
        root.getChildren().setAll(node);
    }

    public Parent getNode(final Class<?> control, URL location) {
        FXMLLoader loader = new FXMLLoader(location);
//        loader.setResources(MESSAGES_BUNDLE);
        loader.setControllerFactory(aClass -> applicationContext.getBean(control));

        try {
            return loader.load();
        } catch (Exception e) {
            LOGGER.error(ERROR_CASTING_NODE, e);
            return null;
        }
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public void close() {
        System.exit(0);
    }

}
