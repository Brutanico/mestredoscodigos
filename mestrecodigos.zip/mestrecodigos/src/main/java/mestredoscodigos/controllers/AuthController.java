package mestredoscodigos.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;

@Component
public class AuthController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthController.class);

    @FXML
    private TextField username;
    @FXML
    private TextField password;
    @FXML
    private ProgressIndicator progressIndicator;
    @FXML
    private Button btnLogar;
    @FXML
    private CheckBox rememberPassword;
    @FXML
    private CheckBox autoLogin;

    @Autowired
    private AppController appController;

    @FXML
    protected void initialize() {

    }

}